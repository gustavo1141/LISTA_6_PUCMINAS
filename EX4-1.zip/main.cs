using System;
using System.IO;

class Program
{
    static void Main()
    {
        Console.WriteLine("Digite o caminho do arquivo de texto:");
        string caminhoArquivo = Console.ReadLine();

        try
        {
            string conteudoArquivo = File.ReadAllText(caminhoArquivo);
            int contadorA = ContarCaracteresA(conteudoArquivo);

            Console.WriteLine($"A quantidade de caracteres 'a' no arquivo é: {contadorA}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ocorreu um erro ao ler o arquivo: {ex.Message}");
        }
    }

    static int ContarCaracteresA(string texto)
    {
        int contador = 0;

        foreach (char c in texto)
        {
            if (c == 'a' || c == 'A')
            {
                contador++;
            }
        }

        return contador;
    }
}
