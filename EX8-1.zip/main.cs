using System;
using System.IO;

class Program
{
    static void Main()
    {
        Console.WriteLine("Digite a quantidade de veículos que a locadora possui:");
        int quantidadeVeiculos = int.Parse(Console.ReadLine());

        Console.WriteLine("Digite o valor cobrado por cada aluguel:");
        decimal valorAluguel = decimal.Parse(Console.ReadLine());

        // Cálculo do faturamento mensal e anual
        decimal faturamentoMensal = (quantidadeVeiculos * valorAluguel) / 3;
        decimal faturamentoAnual = faturamentoMensal * 12;

        // Cálculo do valor ganho com multas no mês
        decimal valorMultaMensal = (faturamentoMensal / 10) * 0.2m;

        // Cálculo do valor gasto com manutenção anual
        decimal valorManutencaoAnual = (quantidadeVeiculos * 0.02m) * 600;

        // Exibição dos resultados
        Console.WriteLine($"Faturamento mensal: R$ {faturamentoMensal:F2}");
        Console.WriteLine($"Faturamento anual: R$ {faturamentoAnual:F2}");
        Console.WriteLine($"Valor ganho com multas no mês: R$ {valorMultaMensal:F2}");
        Console.WriteLine($"Valor gasto com manutenção anual: R$ {valorManutencaoAnual:F2}");

        // Gravação dos resultados no arquivo resultado.txt
        string caminhoArquivo = "resultado.txt";

        using (StreamWriter writer = new StreamWriter(caminhoArquivo))
        {
            writer.WriteLine($"Faturamento mensal: R$ {faturamentoMensal:F2}");
            writer.WriteLine($"Faturamento anual: R$ {faturamentoAnual:F2}");
            writer.WriteLine($"Valor ganho com multas no mês: R$ {valorMultaMensal:F2}");
            writer.WriteLine($"Valor gasto com manutenção anual: R$ {valorManutencaoAnual:F2}");
        }

        Console.WriteLine($"Resultados gravados no arquivo '{caminhoArquivo}'");
    }
}
