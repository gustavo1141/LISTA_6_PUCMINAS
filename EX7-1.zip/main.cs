using System;
using System.IO;
using System.Linq;

class Program
{
    static void Main()
    {
        Console.WriteLine("Digite a quantidade de letras (N) que deseja inserir:");
        int quantidadeLetras = int.Parse(Console.ReadLine());

        string caminhoArquivo = "letras.txt";

        // Inserir letras no arquivo
        using (StreamWriter writer = new StreamWriter(caminhoArquivo))
        {
            for (int i = 0; i < quantidadeLetras; i++)
            {
                Console.WriteLine($"Digite a letra {i + 1}:");
                char letra = char.Parse(Console.ReadLine());
                writer.Write(letra);
            }
        }

        // Ler letras do arquivo e contar vogais
        try
        {
            string conteudo = File.ReadAllText(caminhoArquivo);
            int quantidadeVogais = CalcularQuantidadeVogais(conteudo);

            Console.WriteLine($"O conteúdo do arquivo é: {conteudo}");
            Console.WriteLine($"A quantidade de vogais no arquivo é: {quantidadeVogais}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ocorreu um erro ao ler o arquivo: {ex.Message}");
        }
    }

    static int CalcularQuantidadeVogais(string texto)
    {
        char[] vogais = { 'a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U' };
        int contador = 0;

        foreach (char c in texto)
        {
            if (vogais.Contains(c))
            {
                contador++;
            }
        }

        return contador;
    }
}
