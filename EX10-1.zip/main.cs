using System;
using System.IO;
using System.Linq;

class Program
{
    static void Main()
    {
        string caminhoArquivo = "numeros.txt";

        // Verifica se o arquivo existe
        if (!File.Exists(caminhoArquivo))
        {
            Console.WriteLine($"O arquivo '{caminhoArquivo}' não existe.");
            return;
        }

        try
        {
            // Lê todas as linhas do arquivo
            string[] linhas = File.ReadAllLines(caminhoArquivo);

            // Converte as linhas para números em ponto flutuante
            double[] numeros = linhas.Select(double.Parse).ToArray();

            if (numeros.Length == 0)
            {
                Console.WriteLine("O arquivo está vazio.");
                return;
            }

            // Calcula o valor máximo, mínimo e a média
            double valorMaximo = numeros.Max();
            double valorMinimo = numeros.Min();
            double media = numeros.Average();

            // Imprime os resultados na tela
            Console.WriteLine($"Valor máximo: {valorMaximo}");
            Console.WriteLine($"Valor mínimo: {valorMinimo}");
            Console.WriteLine($"Média: {media}");

        }
        catch (FormatException)
        {
            Console.WriteLine("O arquivo contém dados inválidos. Certifique-se de que todas as linhas contenham números válidos.");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ocorreu um erro ao ler o arquivo: {ex.Message}");
        }
    }
}
