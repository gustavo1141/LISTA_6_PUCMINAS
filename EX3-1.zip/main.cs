using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Digite uma frase:");
        string frase = Console.ReadLine();

        string fraseCodificada = CodificarCesar(frase, 3);

        Console.WriteLine($"Frase codificada: {fraseCodificada}");
    }

    static string CodificarCesar(string texto, int deslocamento)
    {
        string resultado = "";

        foreach (char c in texto)
        {
            if (char.IsLetter(c))
            {
                char deslocado = (char)(c + deslocamento);

                if (char.IsLower(c) && deslocado > 'z' || char.IsUpper(c) && deslocado > 'Z')
                {
                    deslocado = (char)(deslocado - 26);
                }

                resultado += deslocado;
            }
            else
            {
                resultado += c;
            }
        }

        return resultado.ToUpper();
    }
}
