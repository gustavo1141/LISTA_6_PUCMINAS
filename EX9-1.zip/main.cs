using System;
using System.IO;

class Program
{
    static void Main()
    {
        string caminhoArquivo = "dados_alunos.txt";

        while (true)
        {
            Console.WriteLine("Escolha uma opção:");
            Console.WriteLine("1. Inserir dados de alunos");
            Console.WriteLine("2. Ler dados de alunos");
            Console.WriteLine("3. Sair");
            string opcao = Console.ReadLine();

            if (opcao == "1")
            {
                InserirDadosAlunos(caminhoArquivo);
            }
            else if (opcao == "2")
            {
                LerDadosAlunos(caminhoArquivo);
            }
            else if (opcao == "3")
            {
                break;
            }
            else
            {
                Console.WriteLine("Opção inválida. Tente novamente.");
            }
        }
    }

    static void InserirDadosAlunos(string caminhoArquivo)
    {
        using (StreamWriter writer = new StreamWriter(caminhoArquivo, true))
        {
            while (true)
            {
                Console.WriteLine("Digite a matrícula do aluno (ou deixe em branco para terminar):");
                string matricula = Console.ReadLine();

                if (string.IsNullOrEmpty(matricula))
                {
                    break;
                }

                Console.WriteLine("Digite o telefone do aluno:");
                string telefone = Console.ReadLine();

                writer.WriteLine($"{matricula},{telefone}");
            }
        }
    }

    static void LerDadosAlunos(string caminhoArquivo)
    {
        if (!File.Exists(caminhoArquivo))
        {
            Console.WriteLine("O arquivo não existe. Insira dados de alunos primeiro.");
            return;
        }

        using (StreamReader reader = new StreamReader(caminhoArquivo))
        {
            string linha;
            while ((linha = reader.ReadLine()) != null)
            {
                string[] dados = linha.Split(',');
                string matricula = dados[0];
                string telefone = dados[1];

                Console.WriteLine($"Matrícula: {matricula}, Telefone: {telefone}");
            }
        }
    }
}
