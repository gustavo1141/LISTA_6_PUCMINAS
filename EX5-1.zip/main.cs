using System;
using System.IO;

class Program
{
    static void Main()
    {
        Console.WriteLine("Digite o caminho do arquivo de texto:");
        string caminhoArquivo = Console.ReadLine();

        try
        {
            string[] linhas = File.ReadAllLines(caminhoArquivo);

            Console.WriteLine("Conteúdo do arquivo:");

            foreach (string linha in linhas)
            {
                Console.WriteLine(linha);
            }

            Console.WriteLine($"\nA quantidade de linhas no arquivo é: {linhas.Length}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ocorreu um erro ao ler o arquivo: {ex.Message}");
        }
    }
}
